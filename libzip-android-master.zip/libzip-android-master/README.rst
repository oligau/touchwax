libzip for Android
==================
This is a repackaging of libzip for the Android NDK.

The only changed files are config.h and the android .mk files.

libzip has been written by Dieter Baron and Thomas Klausner.

Assuming 'ndk-build' is in your path, you can use the build.sh script to build a static lib.
